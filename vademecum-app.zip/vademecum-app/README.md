# Vademécum IA

## Resumen ejecutivo

Vademécum IA es una aplicación SaaS que permite consultar de manera segura tratamientos y medicamentos disponibles para una enfermedad o condición médica. Un administrador médico carga una única vez el vademécum oficial en formato CSV/XLSX/JSON; el sistema lo estructura en PostgreSQL y expone consultas para los usuarios. La inteligencia artificial de OpenAI actúa **solo** como capa de presentación: interpreta la condición escrita por el usuario, busca la enfermedad correcta en la base de datos y genera una respuesta ordenada y en español neutro, siempre basada exclusivamente en los datos almacenados. La IA no inventa medicamentos ni dosis, y aplica reglas de seguridad según el perfil del paciente.

## Arquitectura

- **Frontend**: Next.js (React) con TypeScript y Tailwind CSS. Se usa el App Router para organizar las rutas y páginas. La navegación está protegida por middleware y NextAuth para roles y autenticación.
- **Backend**: API Routes de Next.js (Node.js) que exponen endpoints para cargar el vademécum, realizar búsquedas y generar respuestas con la IA. Cada petición pasa por el backend; nunca se expone la clave de OpenAI en el navegador.
- **Base de datos**: PostgreSQL manejado a través de Prisma ORM. Prisma facilita la creación de modelos y migraciones. La documentación oficial de Prisma muestra cómo integrar Prisma con Next.js y desplegar en Vercel【529612997622367†L63-L66】. Además, una guía de Vercel recomienda usar Next.js como framework de React, API Routes como backend, Prisma como ORM y Postgres como base de datos, y NextAuth para autenticación【787710782100848†L35-L47】.
- **Autenticación**: NextAuth con proveedor de credenciales y adaptador de Prisma. Los roles `SUPERADMIN`, `ADMIN` y `USER` se almacenan en la tabla `User` y se incrustan en el token de sesión.
- **Inteligencia artificial**: se utiliza OpenAI API (modelos GPT‑3.5‑turbo) con la funcionalidad de *function calling*. La guía de Vercel describe que la función de llamada permite recibir funciones predefinidas y devolver un JSON con los argumentos para ejecutarlas【218150715174397†L36-L49】. El flujo consiste en enviar el mensaje del usuario junto con la lista de funciones, dejar que el modelo decida invocar una función, ejecutar la función en el backend y luego devolver el resultado al modelo para que genere un resumen【218150715174397†L61-L69】. En este proyecto la función `formatDiseaseInfo` formatea la información del vademécum y evita que la IA invente datos.

## Roles y permisos

| Rol          | Permisos principales |
|--------------|----------------------|
| `SUPERADMIN` | Control total del sistema. Gestiona administradores, usuarios y configuración global. Acceso a auditoría completa. |
| `ADMIN`      | Carga única y actualización del vademécum, edición de enfermedades/medicamentos/dosis, desactivación de registros, visualización de historial de consultas. |
| `USER`       | Consulta enfermedades, selecciona perfil de paciente, visualiza respuestas y su historial personal. No puede modificar el vademécum. |

Los roles se almacenan en el modelo `User` (campo `role`) y se inyectan en el token JWT de NextAuth. Un middleware restringe el acceso a rutas bajo `/admin` para usuarios con roles `ADMIN` o `SUPERADMIN`.

## Modelo de datos

El esquema Prisma (`prisma/schema.prisma`) define las siguientes entidades clave:

- **User**: usuario del sistema con campos `email`, `password` (hash), `role`, fechas y relaciones a `UserProfile`, `Query` y `AuditLog`.
- **UserProfile**: datos clínicos opcionales del paciente (edad, peso, embarazo, lactancia, alergias, comorbilidades).
- **Disease**: enfermedad o condición con nombre único, lista de sinónimos, descripción y estado activo.
- **Medication**: medicamento con nombre, principio activo y presentación.
- **DiseaseMedication**: relación que define las reglas clínicas entre una enfermedad y un medicamento: dosis, frecuencia, duración, vía, edades/pesos mínimos y máximos, permiso en embarazo/lactancia, contraindicaciones, interacciones, alergias, red flags y observaciones.
- **Query**: historial de consultas realizadas por los usuarios, registrando enfermedad, perfil de paciente y hora.
- **AuditLog**: registro de cambios administrativos (inserción/edición/eliminación) con usuario y descripción de los cambios.

Se permite ampliar el modelo con tablas adicionales para auditar operaciones más detalladas o gestionar catálogos clínicos externos.

## Estructura de carpetas

```
vademecum-app/
├── app/                 # Rutas y páginas de Next.js (App Router)
│   ├── api/             # API Routes (autenticación, vademécum, chat)
│   ├── admin/           # Área administrativa
│   │   ├── vademecum/   # Módulos de vademécum (carga, listado, detalle)
│   │   └── historial/   # Historial de consultas
│   ├── consulta/        # Página de consulta para usuarios
│   ├── login/           # Página de inicio de sesión
│   └── not-found.tsx    # Página de error 404
├── components/          # Componentes reutilizables (Navbar, Providers)
├── lib/                 # Utilidades compartidas (Prisma, autenticación, OpenAI)
├── prisma/              # Esquema Prisma y script de seed
├── examples/            # Ejemplo de vademécum (CSV)
├── middleware.ts        # Middleware para proteger rutas administradas
├── tailwind.config.js   # Configuración de Tailwind CSS
├── next.config.js       # Configuración de Next.js
├── package.json         # Definición de dependencias y scripts
├── tsconfig.json        # Configuración de TypeScript
└── README.md            # Este documento
```

## Instalación local

1. **Requisitos:** Node.js ≥ 20 y npm. Tener una base de datos PostgreSQL disponible (por ejemplo, Neon, Supabase o local).
2. Clonar el repositorio y entrar a la carpeta `vademecum-app`.
3. Copiar el archivo `.env.example` a `.env` y completar los valores de `DATABASE_URL`, `NEXTAUTH_SECRET` y `OPENAI_API_KEY`.
4. Instalar dependencias:
   ```bash
   npm install
   ```
5. Crear las tablas de la base de datos usando Prisma. Puede ejecutar las migraciones o sincronizar el esquema directamente:
   ```bash
   npx prisma db push
   # o bien
   npx prisma migrate dev --name init
   ```
6. (Opcional) Ejecutar el script de datos de ejemplo:
   ```bash
   npm run seed
   ```
7. Iniciar el servidor en modo desarrollo:
   ```bash
   npm run dev
   ```
   La aplicación estará disponible en `http://localhost:3000`.

## Despliegue

El proyecto se ha preparado para desplegarse en plataformas de hosting serverless como **Vercel** (frontend y API) y bases de datos gestionadas como **Neon**, **Supabase** o **Railway**. Para desplegar:

1. Crear un repositorio en GitHub y subir el contenido de `vademecum-app`.
2. Crear un proyecto en Vercel e importar el repositorio. Vercel detectará automáticamente Next.js y creará la aplicación. Seleccionar la región más cercana.
3. En la sección **Environment Variables** de Vercel, definir `DATABASE_URL`, `NEXTAUTH_SECRET` y `OPENAI_API_KEY`. Si utiliza una base de datos de Vercel, la documentación indica que se puede crear una instancia de Postgres y las variables de conexión se añaden automáticamente【787710782100848†L90-L101】.
4. Realizar el despliegue. Vercel construirá el frontend y backend y lo servirá bajo un subdominio gratuito. Puede asociar su propio dominio desde la configuración del proyecto.
5. (Opcional) Conectar la base de datos externa (Neon/Supabase) y actualizar `DATABASE_URL` en Vercel.

## Herramientas de IA y reglas clínicas

La ruta `/api/chat` implementa un flujo de *function calling*: se pasan al modelo una serie de funciones disponibles y el modelo decide llamar a `formatDiseaseInfo` para estructurar la información del vademécum. Este flujo sigue los pasos descritos por la guía de Vercel【218150715174397†L61-L69】: el cliente envía un mensaje, el servidor envía la lista de funciones al modelo, el modelo devuelve los argumentos para la función, el servidor ejecuta la función y finalmente el modelo resume la respuesta. Esto garantiza que la IA no genere información inventada y que todas las respuestas provengan exclusivamente del vademécum. Además, el sistema añade advertencias y red flags cuando el paciente pertenece a grupos de riesgo (embarazo, lactancia, pediátrico, etc.).

## Reglas de validación y seguridad

- La IA **nunca** recomienda medicamentos que no estén en la base. Si no existe coincidencia, responde que no hay información suficiente.
- Los datos clínicos del paciente se utilizan para personalizar la respuesta. Si el perfil implica riesgo (embarazada, pediátrico, adulto mayor, comorbilidades), se aplican advertencias y se recomienda consultar a un médico.
- Se registra un historial de consultas por usuario para auditoría y seguimiento.
- Sólo los roles `ADMIN` y `SUPERADMIN` pueden cargar o editar el vademécum; el middleware impide el acceso desde otros perfiles.
- Las claves secretas (`DATABASE_URL`, `NEXTAUTH_SECRET`, `OPENAI_API_KEY`) se mantienen en variables de entorno y nunca se envían al cliente.

## Recomendaciones de escalabilidad

- **Base de datos**: usar una instancia gestionada (Supabase, Neon) con réplicas en la misma región que Vercel para reducir latencia. Configurar índices en los campos `name` y `synonyms` de `Disease` para mejorar la búsqueda.
- **Carga del vademécum**: para archivos muy grandes, procesar la carga en lotes y mostrar un progreso al administrador. Considerar el uso de colas (RabbitMQ, SQS) para importar de manera asíncrona.
- **Control de versiones**: versionar el vademécum cargado para permitir restaurar estados anteriores y auditar cambios.
- **Cumplimiento regulatorio**: revisar regulaciones locales sobre software médico (ej. MDR en Europa, HIPAA en EE.UU.) y cumplir con prácticas de manejo de datos sensibles. Implementar cifrado de datos en tránsito y en reposo, y políticas de acceso mínimo.

## Licencia y créditos

Este proyecto se proporciona como un prototipo educativo. Se inspira en guías oficiales de Prisma y Vercel sobre cómo integrar Next.js con Prisma, Postgres y NextAuth【529612997622367†L63-L66】【787710782100848†L35-L47】, así como en la guía de Vercel para implementar *function calling* con OpenAI【218150715174397†L61-L69】. Ajuste y revise la aplicación antes de usarla en entornos de producción o para fines clínicos reales.