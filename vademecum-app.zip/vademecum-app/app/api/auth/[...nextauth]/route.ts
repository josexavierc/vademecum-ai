import NextAuth from 'next-auth';
import { authOptions } from '@/lib/auth';

// Exporta los handlers para GET y POST, permitiendo a NextAuth gestionar
// automáticamente las peticiones. Esta ruta se encarga de iniciar sesión,
// cerrar sesión y manejar callbacks de autenticación.
const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };