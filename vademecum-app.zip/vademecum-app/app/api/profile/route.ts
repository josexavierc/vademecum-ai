import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  }
  const profile = await prisma.patientProfile.findUnique({
    where: { userId: session.user.id },
  });
  return NextResponse.json(profile || {});
}

export async function PUT(request: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  }
  const data = await request.json();
  const { ageGroup, pregnant, lactating, allergies, comorbidities, medications } = data;
  const profile = await prisma.patientProfile.upsert({
    where: { userId: session.user.id },
    update: {
      ageGroup,
      pregnant,
      lactating,
      allergies,
      comorbidities,
      medications,
    },
    create: {
      userId: session.user.id,
      ageGroup,
      pregnant,
      lactating,
      allergies,
      comorbidities,
      medications,
    },
  });
  return NextResponse.json(profile);
}