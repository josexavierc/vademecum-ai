import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { generateAnswer } from '@/lib/openai';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const query: string = (body.query || '').trim();
    const profile: string = (body.profile || 'ADULT').trim();
    if (!query) {
      return NextResponse.json({ error: 'Consulta vacía' }, { status: 400 });
    }
    // Find disease by name or synonyms (case insensitive)
    const disease = await prisma.disease.findFirst({
      where: {
        active: true,
        OR: [
          { name: { contains: query, mode: 'insensitive' } },
          { synonyms: { has: query.toLowerCase() } },
        ],
      },
      include: {
        diseaseMedications: {
          where: { active: true },
          include: {
            medication: true,
          },
        },
      },
    });

    if (!disease) {
      const fallback = {
        condition: query,
        match: '',
        medications: '',
        usage: '',
        dosage: '',
        warnings: '',
        noSelfMedication: '',
        whenToSeekHelp: '',
        disclaimer:
          'No encuentro esta condición en el vademécum cargado. Por favor consulta a un profesional de salud.',
      };
      return NextResponse.json(fallback, { status: 200 });
    }
    // Build structured data from disease and its medications
    const meds = disease.diseaseMedications;
    const medicationsList: string[] = [];
    let dosage = '';
    let warnings: string[] = [];
    let whenToSeekHelp: string[] = [];
    meds.forEach((dm) => {
      medicationsList.push(dm.medication.name);
      const parts: string[] = [];
      if (dm.dose) parts.push(`Dosis: ${dm.dose}`);
      if (dm.frequency) parts.push(`Frecuencia: ${dm.frequency}`);
      if (dm.duration) parts.push(`Duración: ${dm.duration}`);
      if (dm.route) parts.push(`Vía: ${dm.route}`);
      dosage += `${dm.medication.name}: ${parts.join(', ')}\n`;
      if (dm.contraindications) warnings.push(`Contraindicaciones: ${dm.contraindications}`);
      if (dm.interactions) warnings.push(`Interacciones: ${dm.interactions}`);
      if (dm.allergies) warnings.push(`Alergias: ${dm.allergies}`);
      if (dm.notes) warnings.push(`Observaciones: ${dm.notes}`);
      if (dm.redFlags) whenToSeekHelp.push(dm.redFlags);
    });
    // Generic messages
    const noSelfMedication =
      profile === 'ADULT'
        ? 'No te automediques si tienes alergias, estás embarazada, lactando o padeces enfermedades crónicas.'
        : profile === 'PEDIATRIC'
        ? 'No automedicarse en niños. Consulta siempre a un pediatra.'
        : profile === 'ELDERLY'
        ? 'En adultos mayores se recomienda valoración médica antes de tomar cualquier medicamento.'
        : 'No automedicarse y buscar consejo médico.';
    const whenToSeekHelpMsg = whenToSeekHelp.length
      ? whenToSeekHelp.join('\n')
      : 'Si los síntomas empeoran, aparecen nuevas molestias o el tratamiento no mejora la condición, acude a un médico.';
    const structured = {
      condition: query,
      match: disease.name,
      medications: medicationsList.join(', '),
      usage: disease.description || '',
      dosage: dosage.trim(),
      warnings: warnings.join('\n'),
      noSelfMedication,
      whenToSeekHelp: whenToSeekHelpMsg,
      disclaimer:
        'Esta información es solo de referencia basada en el vademécum proporcionado. No reemplaza la consulta con un profesional de la salud.',
    };
    // Call OpenAI to rephrase and format the answer safely
    let answerText = '';
    try {
      answerText = (await generateAnswer(structured)) || '';
    } catch (error) {
      // ignore openai errors; fall back to structured data
      console.error('Error generating answer', error);
    }
    if (answerText) {
      // Ideally the AI returns a properly formatted answer. We return it as plain text.
      return NextResponse.json({ ...structured, ai: answerText });
    }
    return NextResponse.json(structured);
  } catch (error: any) {
    console.error(error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}