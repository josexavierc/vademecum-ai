import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

// Helper to convert strings like "sí"/"no" or "true"/"false" to booleans
function parseBoolean(value: any): boolean | null {
  if (value === null || value === undefined || value === '') return null;
  const v = String(value).toLowerCase();
  if (['yes', 'sí', 'si', 'true', '1'].includes(v)) return true;
  if (['no', 'false', '0'].includes(v)) return false;
  return null;
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user || !['ADMIN', 'SUPERADMIN'].includes(session.user.role)) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  }
  try {
    const body = await request.json();
    const records: any[] = body.records;
    if (!Array.isArray(records) || records.length === 0) {
      return NextResponse.json({ error: 'No se proporcionaron registros' }, { status: 400 });
    }
    for (const record of records) {
      const diseaseName: string = record.enfermedad?.trim();
      if (!diseaseName) continue;
      const synonymsRaw: string = record.sinonimos || '';
      const synonyms = synonymsRaw
        .split(/[;,]/)
        .map((s: string) => s.trim().toLowerCase())
        .filter((s: string) => s.length > 0);
      const medicationName: string = record.medicamento?.trim();
      if (!medicationName) continue;
      const disease = await prisma.disease.upsert({
        where: { name: diseaseName },
        update: { synonyms },
        create: {
          name: diseaseName,
          synonyms,
          description: record.descripcion || null,
          active: true,
        },
      });
      const medication = await prisma.medication.upsert({
        where: { name: medicationName },
        update: {
          activePrinciple: record.principio_activo || null,
          presentation: record.presentacion || null,
          active: true,
        },
        create: {
          name: medicationName,
          activePrinciple: record.principio_activo || null,
          presentation: record.presentacion || null,
          active: true,
        },
      });
      // Create or update DiseaseMedication entry
      await prisma.diseaseMedication.upsert({
        where: {
          diseaseId_medicationId: {
            diseaseId: disease.id,
            medicationId: medication.id,
          },
        },
        update: {
          dose: record.dosis || null,
          frequency: record.frecuencia || null,
          duration: record.duracion || null,
          route: record.via_administracion || null,
          ageMin: record.edad_minima ? Number(record.edad_minima) : null,
          ageMax: record.edad_maxima ? Number(record.edad_maxima) : null,
          weightMin: record.peso_minimo ? parseFloat(record.peso_minimo) : null,
          weightMax: record.peso_maximo ? parseFloat(record.peso_maximo) : null,
          pregnancyAllowed: parseBoolean(record.embarazo_permitido),
          lactationAllowed: parseBoolean(record.lactancia_permitido),
          contraindications: record.contraindicaciones || null,
          interactions: record.interacciones || null,
          allergies: record.alergias || null,
          redFlags: record.red_flags || null,
          notes: record.observaciones || null,
          active: record.estado === undefined || String(record.estado).toLowerCase() !== 'inactivo',
        },
        create: {
          diseaseId: disease.id,
          medicationId: medication.id,
          dose: record.dosis || null,
          frequency: record.frecuencia || null,
          duration: record.duracion || null,
          route: record.via_administracion || null,
          ageMin: record.edad_minima ? Number(record.edad_minima) : null,
          ageMax: record.edad_maxima ? Number(record.edad_maxima) : null,
          weightMin: record.peso_minimo ? parseFloat(record.peso_minimo) : null,
          weightMax: record.peso_maximo ? parseFloat(record.peso_maximo) : null,
          pregnancyAllowed: parseBoolean(record.embarazo_permitido),
          lactationAllowed: parseBoolean(record.lactancia_permitido),
          contraindications: record.contraindicaciones || null,
          interactions: record.interacciones || null,
          allergies: record.alergias || null,
          redFlags: record.red_flags || null,
          notes: record.observaciones || null,
          active: record.estado === undefined || String(record.estado).toLowerCase() !== 'inactivo',
        },
      });
    }
    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error(error);
    return NextResponse.json({ error: 'Error al importar el vademécum' }, { status: 500 });
  }
}