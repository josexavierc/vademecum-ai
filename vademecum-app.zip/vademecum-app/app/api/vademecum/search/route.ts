import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getToken } from 'next-auth/jwt';

/**
 * API para buscar una enfermedad en el vademécum. Recibe un término de
 * búsqueda y un perfil de paciente opcional y devuelve la enfermedad y sus
 * medicamentos asociados. También registra la consulta en el historial del
 * usuario si éste está autenticado.
 */
export async function POST(req: NextRequest) {
  const { condition, profile } = await req.json();
  if (!condition || typeof condition !== 'string') {
    return NextResponse.json({ error: 'Condición no válida' }, { status: 400 });
  }
  const search = condition.trim().toLowerCase();
  // Busca por nombre exacto o sinónimos que contengan el término.
  const disease = await prisma.disease.findFirst({
    where: {
      OR: [
        { name: search },
        { synonyms: { has: search } },
      ],
      active: true,
    },
    include: {
      medications: {
        where: { active: true },
        include: {
          medication: true,
        },
      },
    },
  });
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (disease) {
    // Registra el historial si hay sesión.
    if (token?.id) {
      await prisma.query.create({
        data: {
          userId: token.id as string,
          diseaseId: disease.id,
          patientProfile: profile || null,
          response: null,
        },
      });
    }
    return NextResponse.json({ found: true, disease });
  } else {
    // No se encontró la enfermedad
    return NextResponse.json({ found: false });
  }
}