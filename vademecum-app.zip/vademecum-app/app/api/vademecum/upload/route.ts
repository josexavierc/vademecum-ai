import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { getToken } from 'next-auth/jwt';
import { prisma } from '@/lib/prisma';
import { parse } from 'csv-parse/sync';
import * as XLSX from 'xlsx';

/**
 * API para cargar y procesar el vademécum. Solo accesible para usuarios
 * administradores. Acepta carga en formato JSON (preferido en este MVP) así
 * como CSV o XLSX. Cada registro debe contener los campos definidos en la
 * especificación del vademécum. Los medicamentos y enfermedades se
 * upsertean para evitar duplicados.
 */
export async function POST(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token || (token.role !== 'ADMIN' && token.role !== 'SUPERADMIN')) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  }

  const contentType = req.headers.get('content-type') || '';
  let records: any[] = [];
  try {
    if (contentType.includes('application/json')) {
      records = await req.json();
    } else if (contentType.includes('text/csv')) {
      const text = await req.text();
      records = parse(text, { columns: true, skip_empty_lines: true });
    } else if (
      contentType.includes('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') ||
      contentType.includes('application/vnd.ms-excel')
    ) {
      const buffer = Buffer.from(await req.arrayBuffer());
      const workbook = XLSX.read(buffer, { type: 'buffer' });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      records = XLSX.utils.sheet_to_json(sheet);
    } else {
      return NextResponse.json({ error: 'Formato no soportado' }, { status: 400 });
    }
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: 'Error al procesar el archivo' }, { status: 500 });
  }

  let inserted = 0;
  for (const rec of records) {
    // Normaliza los campos: asume nombres de columna en español con espacios
    const enfermedad = rec.enfermedad?.toString().trim().toLowerCase();
    const sinónimos = rec['sinónimos de enfermedad'] || rec['sinonimos'] || rec['sinónimos'] || '';
    const description = rec['descripción breve'] || rec.descripcion || '';
    const medicamentoNombre = rec.medicamento?.toString().trim();
    if (!enfermedad || !medicamentoNombre) continue;
    // Upsert enfermedad
    const disease = await prisma.disease.upsert({
      where: { name: enfermedad },
      update: {
        synonyms: typeof sinónimos === 'string' ? sinónimos.split(/[,;]\s*/) : [],
        description,
      },
      create: {
        name: enfermedad,
        synonyms: typeof sinónimos === 'string' ? sinónimos.split(/[,;]\s*/) : [],
        description,
      },
    });
    // Upsert medicamento
    const medication = await prisma.medication.upsert({
      where: { name: medicamentoNombre },
      update: {
        activeIngredient: rec['principio activo'] || rec.principio || undefined,
        presentation: rec['presentación'] || rec.presentacion || undefined,
      },
      create: {
        name: medicamentoNombre,
        activeIngredient: rec['principio activo'] || rec.principio || undefined,
        presentation: rec['presentación'] || rec.presentacion || undefined,
      },
    });
    // Crea regla de relación
    await prisma.diseaseMedication.create({
      data: {
        diseaseId: disease.id,
        medicationId: medication.id,
        dosage: rec.dosis || undefined,
        frequency: rec.frecuencia || undefined,
        duration: rec.duracion || undefined,
        route: rec['vía de administración'] || rec.via || undefined,
        minAge: rec['edad mínima'] ? parseInt(rec['edad mínima']) : undefined,
        maxAge: rec['edad máxima'] ? parseInt(rec['edad máxima']) : undefined,
        minWeight: rec['peso mínimo'] ? parseFloat(rec['peso mínimo']) : undefined,
        maxWeight: rec['peso máximo'] ? parseFloat(rec['peso máximo']) : undefined,
        pregnancyAllowed: rec['embarazo permitido'] ? rec['embarazo permitido'].toString().toLowerCase() === 'sí' : undefined,
        lactationAllowed: rec['lactancia permitido'] ? rec['lactancia permitido'].toString().toLowerCase() === 'sí' : undefined,
        contraindications: rec.contraindicaciones || undefined,
        interactions: rec.interacciones || undefined,
        allergies: rec['alergias relevantes'] || undefined,
        redFlags: rec['red flags'] || undefined,
        observations: rec.observaciones || undefined,
      },
    });
    inserted++;
  }
  return NextResponse.json({ success: true, inserted });
}