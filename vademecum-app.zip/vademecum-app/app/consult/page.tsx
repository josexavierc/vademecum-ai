"use client";

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';

interface Answer {
  condition: string;
  match: string;
  medications: string;
  usage: string;
  dosage: string;
  warnings: string;
  noSelfMedication: string;
  whenToSeekHelp: string;
  disclaimer: string;
}

export default function ConsultPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const [query, setQuery] = useState('');
  const [profile, setProfile] = useState('ADULT');
  const [loading, setLoading] = useState(false);
  const [answer, setAnswer] = useState<Answer | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setAnswer(null);
    try {
      const res = await fetch('/api/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, profile }),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || 'Error en la consulta');
      }
      const data = await res.json();
      setAnswer(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl p-4">
      <h1 className="text-2xl font-semibold my-4 text-center">Consultar enfermedad</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1 font-medium" htmlFor="query">
            Enfermedad o condición
          </label>
          <input
            id="query"
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            required
            className="w-full rounded border p-2"
          />
        </div>
        <div>
          <label className="block mb-1 font-medium" htmlFor="profile">
            Perfil del paciente
          </label>
          <select
            id="profile"
            value={profile}
            onChange={(e) => setProfile(e.target.value)}
            className="w-full rounded border p-2"
          >
            <option value="ADULT">Adulto general</option>
            <option value="PEDIATRIC">Pediátrico</option>
            <option value="ELDERLY">Adulto mayor</option>
          </select>
        </div>
        <button
          type="submit"
          disabled={loading}
          className="rounded bg-blue-600 px-6 py-2 text-white hover:bg-blue-700"
        >
          {loading ? 'Consultando...' : 'Consultar'}
        </button>
      </form>
      {error && <p className="text-red-500 mt-4">{error}</p>}
      {answer && (
        <div className="mt-8 space-y-3 bg-white p-4 rounded shadow">
          <h2 className="text-xl font-bold">Resultado</h2>
          <p><strong>Condición consultada:</strong> {answer.condition}</p>
          <p><strong>Coincidencia encontrada:</strong> {answer.match}</p>
          <p><strong>Medicamentos:</strong> {answer.medications}</p>
          <p><strong>Uso:</strong> {answer.usage}</p>
          <p><strong>Dosis y frecuencia:</strong> {answer.dosage}</p>
          <p><strong>Advertencias importantes:</strong> {answer.warnings}</p>
          <p><strong>No automedicarse si:</strong> {answer.noSelfMedication}</p>
          <p><strong>Acudir a un médico si:</strong> {answer.whenToSeekHelp}</p>
          <p className="text-sm italic text-gray-600">{answer.disclaimer}</p>
        </div>
      )}
    </div>
  );
}