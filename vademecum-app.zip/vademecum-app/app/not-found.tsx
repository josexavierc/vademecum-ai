export default function NotFound() {
  return (
    <div className="text-center py-20">
      <h1 className="text-3xl font-bold mb-4">Página no encontrada</h1>
      <p className="text-gray-600 mb-6">La página solicitada no existe.</p>
      <a
        href="/"
        className="inline-block bg-primary text-white px-6 py-3 rounded hover:bg-teal-700"
      >
        Volver al inicio
      </a>
    </div>
  );
}