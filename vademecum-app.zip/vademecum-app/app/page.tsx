export default function Home() {
  return (
    <section className="py-10 text-center">
      <h1 className="text-3xl font-bold mb-4 text-primary">Vademécum IA</h1>
      <p className="mb-6 text-gray-700 max-w-2xl mx-auto">
        Consulta de forma segura y sencilla recomendaciones de medicamentos basadas en un vademécum administrado por expertos. La inteligencia artificial interpreta tu consulta y devuelve información organizada sin inventar datos.
      </p>
      <a
        href="/consulta"
        className="inline-block bg-primary text-white px-6 py-3 rounded hover:bg-teal-700 transition"
      >
        Comenzar consulta
      </a>
    </section>
  );
}