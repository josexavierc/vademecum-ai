"use client";
import Link from 'next/link';
import { useSession } from 'next-auth/react';

/**
 * Barra de navegación superior. Muestra enlaces a las diferentes secciones
 * dependiendo de si el usuario está autenticado y su rol. Utiliza
 * `useSession` para obtener la sesión en el cliente.
 */
export default function Navbar() {
  const { data: session } = useSession();
  const role = (session?.user as any)?.role;
  return (
    <nav className="bg-white shadow mb-6">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <Link href="/" className="font-semibold text-lg text-primary">
          Vademécum&nbsp;IA
        </Link>
        <div className="flex gap-4 text-sm">
          <Link href="/consulta" className="hover:underline">
            Consulta
          </Link>
          {role === 'ADMIN' || role === 'SUPERADMIN' ? (
            <Link href="/admin" className="hover:underline">
              Admin
            </Link>
          ) : null}
          {session ? (
            <Link href="/api/auth/signout?callbackUrl=/" className="hover:underline">
              Salir
            </Link>
          ) : (
            <Link href="/login" className="hover:underline">
              Ingresar
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}