"use client";
import { SessionProvider } from 'next-auth/react';
import { ReactNode } from 'react';

/**
 * Proveedor de contexto globales de la aplicación. En este MVP sólo
 * incluimos el SessionProvider de NextAuth para gestionar la sesión en el
 * cliente. Puede ampliarse con otros providers (por ejemplo, para temas de UI).
 */
export default function Providers({ children }: { children: ReactNode }) {
  return <SessionProvider>{children}</SessionProvider>;
}