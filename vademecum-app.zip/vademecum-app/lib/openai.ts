import OpenAI from 'openai';

// Create a single OpenAI client. The API key must be provided via
// environment variables and never sent to the frontend. If no key is
// provided the calls will throw errors.
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// System prompt instructing the model to only use the information
// supplied via the vademécum. It emphasizes that no hallucinations are
// allowed and the output should be in Spanish.
const baseSystemPrompt = `Eres un asistente médico que responde consultas sobre medicamentos y enfermedades exclusivamente con la información provista por un vademécum. Nunca inventas datos, dosis ni recomendaciones que no se encuentren en la base. Respondes en español neutro con claridad, organizando la respuesta en secciones para condición consultada, coincidencia encontrada, medicamentos, dosis y frecuencia, advertencias, cuándo no automedicarse, cuándo consultar un médico y un disclaimer final. Si no hay suficiente información o si existe alguna contraindicación grave, indícalo de manera clara y recomiende acudir a un profesional de la salud.`;

// Generate a chat completion given the structured disease data. The
// `data` argument should contain all the fields needed by the model.
export async function generateAnswer(data: {
  condition: string;
  match: string;
  medications: string;
  usage: string;
  dosage: string;
  warnings: string;
  noSelfMedication: string;
  whenToSeekHelp: string;
  disclaimer: string;
}) {
  const messages = [
    {
      role: 'system' as const,
      content: baseSystemPrompt,
    },
    {
      role: 'user' as const,
      content: `Consulta sobre: ${data.condition}. Datos estructurados: ${JSON.stringify(
        data
      )}`,
    },
  ];
  const completion = await openai.chat.completions.create({
    model: 'gpt-4-1106-preview',
    messages,
    temperature: 0.2,
    max_tokens: 512,
  });
  const answer = completion.choices[0]?.message?.content?.trim();
  return answer;
}