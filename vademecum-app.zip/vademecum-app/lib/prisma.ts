import { PrismaClient } from '@prisma/client';

// Permite reutilizar la instancia de Prisma en desarrollo para evitar
// problemas con Hot Reload. En producción siempre se crea una nueva.
const globalForPrisma = global as unknown as { prisma: PrismaClient };

export const prisma =
  globalForPrisma.prisma ||
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['query', 'error'] : ['error'],
  });

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma;