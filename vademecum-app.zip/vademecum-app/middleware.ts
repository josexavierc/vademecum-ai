import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { getToken } from 'next-auth/jwt';

/**
 * Middleware para proteger rutas según el rol del usuario. En este MVP solo se
 * protegen las rutas bajo `/admin`, restringiendo el acceso a usuarios con
 * rol ADMIN o SUPERADMIN. Si el token no existe o el rol no coincide, se
 * redirecciona al login.
 */
export async function middleware(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  const { pathname } = req.nextUrl;
  // Rutas administrativas
  if (pathname.startsWith('/admin')) {
    if (!token || (token.role !== 'ADMIN' && token.role !== 'SUPERADMIN')) {
      const url = new URL('/login', req.url);
      return NextResponse.redirect(url);
    }
  }
  return NextResponse.next();
}

export const config = {
  matcher: ['/admin/:path*'],
};