/**
 * @type {import('next').NextConfig}
 */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    appDir: true
  },
  images: {
    domains: []
  },
  env: {
    // Expose only non-sensitive environment variables to the browser here.
    NEXT_PUBLIC_APP_NAME: 'Vademécum IA',
  }
};

module.exports = nextConfig;