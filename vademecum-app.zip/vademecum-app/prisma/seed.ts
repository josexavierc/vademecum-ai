import { PrismaClient, Role } from '@prisma/client';

const prisma = new PrismaClient();

/**
 * Script de seed para poblar la base de datos con un usuario administrador y
 * algunas entradas de ejemplo en el vademécum. Este script no se ejecuta
 * automáticamente; debe invocarse manualmente con `npm run seed` después de
 * haber ejecutado las migraciones correspondientes.
 */
async function main() {
  // Crea o actualiza un administrador por defecto. La contraseña debe
  // reemplazarse por un hash generado a partir de una contraseña segura.
  await prisma.user.upsert({
    where: { email: 'admin@demo.com' },
    update: {},
    create: {
      email: 'admin@demo.com',
      name: 'Administrador Demo',
      password: 'changeme',
      role: Role.ADMIN,
    },
  });

  // Ejemplo de enfermedad con medicamentos asociados
  await prisma.disease.create({
    data: {
      name: 'gripe',
      synonyms: ['influenza', 'resfriado común'],
      description: 'Infección viral respiratoria frecuente.',
      medications: {
        create: [
          {
            medication: {
              create: {
                name: 'Paracetamol',
                activeIngredient: 'Acetaminofén',
                presentation: 'Tabletas 500 mg',
              },
            },
            dosage: '500 mg',
            frequency: 'cada 6 horas',
            duration: '5 días',
            route: 'oral',
            minAge: 6,
            maxAge: null,
            pregnancyAllowed: true,
            lactationAllowed: true,
            contraindications: 'Hipersensibilidad conocida al paracetamol',
            interactions: 'Consumo excesivo de alcohol',
            allergies: '',
            redFlags: 'Fiebre persistente, dificultad respiratoria',
            observations: 'Usar con precaución en pacientes con insuficiencia hepática',
          },
          {
            medication: {
              create: {
                name: 'Ibuprofeno',
                activeIngredient: 'Ibuprofeno',
                presentation: 'Tabletas 200 mg',
              },
            },
            dosage: '200 mg',
            frequency: 'cada 8 horas',
            duration: '3 a 5 días',
            route: 'oral',
            minAge: 12,
            maxAge: null,
            pregnancyAllowed: false,
            lactationAllowed: false,
            contraindications: 'Úlcera péptica activa, insuficiencia renal severa',
            interactions: 'Anticoagulantes, otros antiinflamatorios',
            allergies: 'AINEs',
            redFlags: 'Dolor abdominal intenso, vómito con sangre',
            observations: 'No exceder la dosis máxima diaria de 1200 mg',
          },
        ],
      },
    },
  });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });