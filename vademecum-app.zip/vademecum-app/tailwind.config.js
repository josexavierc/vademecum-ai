/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './pages/**/*.{ts,tsx}',
    './lib/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: '#008080',
        secondary: '#00b3b3',
        accent: '#f59e0b'
      }
    },
  },
  plugins: [require('@tailwindcss/forms')],
};